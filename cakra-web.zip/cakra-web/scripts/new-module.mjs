#!/usr/bin/env node
/**
 * Generator kerangka modul. Pakai: `npm run gen:module -- inventory`  (nama: huruf kecil, boleh pakai tanda hubung)
 * Menghasilkan src/modules/<nama>/{api,composables,views,components,stores}, types.ts, index.ts.
 */
import { mkdirSync, writeFileSync, existsSync } from 'node:fs'
import { join, dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const name = process.argv[2]
if (!name || !/^[a-z][a-z0-9-]*$/.test(name)) {
  console.error('Pemakaian: npm run gen:module -- <nama-modul>   (huruf kecil/angka/tanda hubung, mis. "inventory")')
  process.exit(1)
}

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const dir = join(ROOT, 'src', 'modules', name)
if (existsSync(dir)) {
  console.error(`Modul "${name}" sudah ada: ${dir}`)
  process.exit(1)
}

const Pascal = name.split('-').map((s) => s[0].toUpperCase() + s.slice(1)).join('')
const camel = Pascal[0].toLowerCase() + Pascal.slice(1)

const files = {
  'types.ts': `export interface ${Pascal}Item {
  id: number
  name: string
}
`,
  [`api/${name}.api.ts`]: `import { apiList } from '@/core/api/request'
import type { ListQuery } from '@/core/api/types'
import type { ${Pascal}Item } from '../types'

export const ${camel}Api = {
  list(query?: ListQuery, signal?: AbortSignal) {
    return apiList<${Pascal}Item>('/${name}', query, { signal })
  },
}
`,
  [`composables/use${Pascal}List.ts`]: `import { onBeforeUnmount, ref } from 'vue'
import { getApiErrorMessage, isCancelledError } from '@/core/api/errors'
import type { PageMeta } from '@/core/api/types'
import { ${camel}Api } from '../api/${name}.api'
import type { ${Pascal}Item } from '../types'

/** Logika daftar ${name}: state, pemuatan, dan pembatalan request. View hanya menampilkan. */
export function use${Pascal}List() {
  const items = ref<${Pascal}Item[]>([])
  const meta = ref<PageMeta | null>(null)
  const loading = ref(false)
  const error = ref<string | null>(null)
  let controller: AbortController | null = null

  async function load(page = 1) {
    controller?.abort()
    controller = new AbortController()
    loading.value = true
    error.value = null
    try {
      const result = await ${camel}Api.list({ page }, controller.signal)
      items.value = result.items
      meta.value = result.meta
    } catch (e) {
      if (!isCancelledError(e)) error.value = getApiErrorMessage(e)
    } finally {
      loading.value = false
    }
  }

  onBeforeUnmount(() => controller?.abort())

  return { items, meta, loading, error, load }
}
`,
  [`views/${Pascal}ListView.vue`]: `<script setup lang="ts">
import { onMounted } from 'vue'
import PageHeader from '@/shared/components/ui/primitives/PageHeader.vue'
import BaseCard from '@/shared/components/ui/primitives/BaseCard.vue'
import BaseAlert from '@/shared/components/ui/feedback/BaseAlert.vue'
import BaseTable, { type TableColumn } from '@/shared/components/ui/data/BaseTable.vue'
import { use${Pascal}List } from '../composables/use${Pascal}List'

const { items, loading, error, load } = use${Pascal}List()

const columns: TableColumn[] = [
  { key: 'id', label: 'ID', width: '80px' },
  { key: 'name', label: 'Nama' },
]

onMounted(() => load())
</script>

<template>
  <div>
    <PageHeader title="${Pascal}" :breadcrumbs="[{ label: 'Home', to: '/' }, { label: '${Pascal}' }]" />
    <BaseAlert v-if="error" variant="danger">{{ error }}</BaseAlert>
    <BaseCard no-padding>
      <BaseTable :columns="columns" :rows="items" :loading="loading" />
    </BaseCard>
  </div>
</template>
`,
  'index.ts': `/** API publik modul "${name}": hanya ekspor yang boleh dipakai lapisan/modul lain. */
export type { ${Pascal}Item } from './types'
`,
}

for (const [rel, content] of Object.entries(files)) {
  const full = join(dir, rel)
  mkdirSync(dirname(full), { recursive: true })
  writeFileSync(full, content)
}
for (const sub of ['components', 'stores']) {
  mkdirSync(join(dir, sub), { recursive: true })
  writeFileSync(join(dir, sub, '.gitkeep'), '')
}

console.log(`✔ Modul "${name}" dibuat di src/modules/${name}\n`)
console.log('Langkah berikutnya:')
console.log(`  1. Backend: tambahkan menu dengan component_key "${name}/${Pascal}ListView" dan permission-nya.`)
console.log('  2. Sesuaikan types.ts dan api/*.api.ts dengan kontrak endpoint.')
console.log('  3. npm run check   (arsitektur + typecheck)')
