#!/usr/bin/env node
/**
 * Penjaga arsitektur — tanpa dependensi. Jalankan: `npm run check:arch`.
 *
 * Aturan lapisan (panah = "boleh mengimpor"):
 *   app      → core, shared, modules (hanya API publik `@/modules/<x>`; pengecualian: lazy view di app/router)
 *   modules  → core, shared, dirinya sendiri (pakai import RELATIF), modul lain hanya lewat `@/modules/<x>`
 *   shared   → core, shared
 *   core     → core
 * Tambahan: `import.meta.env` hanya boleh di core/config/env.ts; semua import harus terselesaikan ke file nyata.
 */
import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs'
import { join, dirname, resolve, relative, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const SRC = join(ROOT, 'src')
const EXTS = ['', '.ts', '.vue', '.d.ts', '/index.ts', '/index.vue']

function walk(dir) {
  return readdirSync(dir).flatMap((name) => {
    const full = join(dir, name)
    if (statSync(full).isDirectory()) return walk(full)
    return /\.(ts|vue)$/.test(name) && !name.endsWith('.d.ts') ? [full] : []
  })
}

/** Klasifikasi file di bawah src/ → { layer, module?, rest } */
function classify(absPath) {
  const parts = relative(SRC, absPath).split(sep)
  const [layer, second, ...rest] = parts
  if (layer === 'modules') return { layer, module: second, rest }
  return { layer, rest: [second, ...rest].filter(Boolean) }
}

function resolveImport(fromFile, spec) {
  let base
  if (spec.startsWith('@/')) base = join(SRC, spec.slice(2))
  else if (spec.startsWith('.')) base = resolve(dirname(fromFile), spec)
  else return null // paket eksternal
  for (const ext of EXTS) {
    const candidate = base + ext
    if (existsSync(candidate) && statSync(candidate).isFile()) return candidate
  }
  return { missing: spec }
}

const IMPORT_RE = /(?:from\s+|import\s*\(\s*|import\s+)(['"])([^'"\n]+)\1/g
const errors = []
const fail = (file, msg) => errors.push(`${relative(ROOT, file)}: ${msg}`)

for (const file of walk(SRC)) {
  const me = classify(file)
  const text = readFileSync(file, 'utf8')

  if (/import\.meta\.env/.test(text) && relative(SRC, file) !== join('core', 'config', 'env.ts')) {
    fail(file, 'import.meta.env hanya boleh dibaca di core/config/env.ts — pakai `env` dari "@/core/config/env"')
  }

  for (const [, , spec] of text.matchAll(IMPORT_RE)) {
    const target = resolveImport(file, spec)
    if (target === null) continue
    if ('missing' in Object(target)) {
      fail(file, `import tidak terselesaikan: '${spec}'`)
      continue
    }
    const to = classify(target)
    const via = `'${spec}'`

    if (to.layer === 'assets' || to.layer === 'env.d.ts') continue
    if (me.layer === 'core' && to.layer !== 'core') fail(file, `core tidak boleh mengimpor ${to.layer} ${via}`)
    if (me.layer === 'shared' && !['core', 'shared'].includes(to.layer)) fail(file, `shared tidak boleh mengimpor ${to.layer} ${via}`)

    if (me.layer === 'modules') {
      if (to.layer === 'app') fail(file, `modul tidak boleh mengimpor app ${via}`)
      if (to.layer === 'modules') {
        if (to.module === me.module) {
          if (spec.startsWith('@/')) fail(file, `di dalam modul "${me.module}" pakai import relatif, bukan alias ${via}`)
        } else if (to.rest.length > 1 || to.rest[0] !== 'index.ts') {
          fail(file, `impor lintas modul harus lewat API publik '@/modules/${to.module}' (index.ts), bukan ${via}`)
        }
      }
    }

    if (me.layer === 'app' && to.layer === 'modules') {
      const isPublicApi = to.rest.length === 1 && to.rest[0] === 'index.ts'
      const isLazyView = to.rest[0] === 'views' && relative(SRC, file).startsWith(join('app', 'router'))
      if (!isPublicApi && !isLazyView) fail(file, `app hanya boleh mengimpor API publik '@/modules/${to.module}' ${via}`)
    }
  }
}

if (errors.length) {
  console.error(`\n✖ ${errors.length} pelanggaran arsitektur:\n`)
  for (const e of errors) console.error('  - ' + e)
  console.error('\nLihat docs/ARCHITECTURE.md untuk aturan lapisan.\n')
  process.exit(1)
}
console.log(`✔ Arsitektur sesuai aturan (${walk(SRC).length} file diperiksa).`)
