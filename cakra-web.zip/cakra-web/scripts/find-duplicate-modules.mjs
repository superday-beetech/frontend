#!/usr/bin/env node
/** Diagnostik: modul sumber yang masuk >1 chunk. Pakai: `npx vite build --sourcemap && node scripts/find-duplicate-modules.mjs` */
import { readdirSync, readFileSync } from 'node:fs'
const dir = 'dist/assets'
const seen = new Map()
for (const f of readdirSync(dir).filter((f) => f.endsWith('.js.map'))) {
  for (const src of JSON.parse(readFileSync(`${dir}/${f}`, 'utf8')).sources) {
    if (src.includes('node_modules')) continue
    const chunk = f.replace('.js.map', '')
    seen.set(src, [...new Set([...(seen.get(src) ?? []), chunk])]) // satu chunk dihitung sekali
  }
}
const dupes = [...seen].filter(([, chunks]) => chunks.length > 1)
if (!dupes.length) console.log('✔ Tidak ada modul sumber yang terduplikasi antar chunk.')
for (const [src, chunks] of dupes) console.log(`✖ ${src}\n    ${chunks.join('\n    ')}`)
process.exit(dupes.length ? 1 : 0)
