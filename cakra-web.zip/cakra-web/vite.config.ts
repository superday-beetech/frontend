import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import tailwindcss from '@tailwindcss/vite'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')

  return {
    plugins: [vue(), tailwindcss()],

    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url)),
      },
    },

    build: {
      manifest: true,
      sourcemap: mode === 'development',
    },

    server: {
      proxy: {
        '/api': {
          target: env.VITE_DEV_API_TARGET || 'https://cakra.test',
          changeOrigin: true,
          secure: false,
        },
      },
    },
  }
})
/* import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import tailwindcss from '@tailwindcss/vite'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')

  return {
    plugins: [vue(), tailwindcss()],
    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url)),
      },
    },
    server: {
      // Session memakai cookie → di development panggil API lewat proxy (same-origin),
      // sehingga cookie SameSite=Lax berfungsi persis seperti di produksi.
      proxy: {
        '/api': {
          target: env.VITE_DEV_API_TARGET || 'https://api.cakra.test',
          changeOrigin: true,
        },
      },
    },
  }
})
 */
