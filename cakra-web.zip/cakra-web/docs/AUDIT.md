# Audit & Refactor — cakra-web (17 Nov 2026)

> Catatan: struktur folder sudah direstrukturisasi setelah audit ini (lihat `ARCHITECTURE.md`). Nama file di bawah memakai lokasi lama
> (mis. `auth.service.ts` → `modules/auth/api/auth.api.ts`, `http.ts` → `core/api/client.ts`). Butir C4 (dua sistem konfirmasi/mata uang) sudah diselesaikan:
> `useSwal` + `sweetalert2` dihapus, `useConfirm` jadi satu-satunya; `useCurrency` (tak terpakai) dihapus, `core/utils/formatter.ts` jadi satu-satunya.

Catatan: audit dilakukan dengan membaca kode. `npm install`/`vue-tsc`/`vite build` TIDAK bisa dijalankan di
lingkungan audit (tanpa jaringan), jadi perubahan belum diverifikasi oleh compiler. Jalankan `npm run build` dulu.

## A. Bug yang diperbaiki
| # | Lokasi | Masalah | Dampak |
|---|--------|---------|--------|
| 1 | `LoginView.vue` | Memanggil `useFormValidation<...>()` tanpa argumen dan memakai `setErrorsFromResponse` yang tidak ada | `vue-tsc` gagal → `npm run build` gagal; login crash saat error |
| 2 | `LoginView.vue` | Email/password demo terisi default; `?redirect=` dipakai mentah | Kredensial bocor di prod; open redirect |
| 3 | `auth.service.ts` | Mock (token palsu, login apa saja) ikut ter-bundle dan aktif bila env salah | Bypass login di production |
| 4 | `http.ts` | 401 → `window.location.href` (reload penuh, store tidak dibersihkan); 401 saat login ikut memicu | UX buruk, state basi |
| 5 | `router/index.ts` | Route dinamis tidak dihapus saat logout/ganti akun; error jaringan dan 401 diperlakukan sama; penolakan izin diam-diam | Akses route akun sebelumnya; membingungkan |
| 6 | `auth.store.ts` | `logout()` melempar error bila API gagal sehingga redirect ke login tidak jalan; menu tidak difilter izin | User terjebak; menu tampil tapi klik → redirect |
| 7 | `permission.ts` (`v-can`) | `removeChild` manual merusak patching Vue; tidak reaktif | Error render acak; izin berubah tak terdeteksi |
| 8 | `useSwal.ts` | `itemName` masuk ke `html:` tanpa escape | XSS |
| 9 | `useTheme.ts` | Watcher dibuat tiap pemanggilan; tema dibaca async dari IndexedDB → flash terang saat load; tidak ikut prefers-color-scheme | Kedip + watcher ganda |
| 10 | `formatter.ts` | `formatDate('2026-11-17')` diparse UTC (bisa mundur sehari); tanggal tidak valid melempar RangeError; NaN lolos | Tanggal salah / halaman crash |
| 11 | `BaseTableFull.vue` | Halaman tidak reset saat cari/filter/sort (tabel tampak kosong); sort `<`/`>` tidak aman untuk null/angka-teks; `row.id \|\| idx` gagal untuk id 0 | Data "hilang" |
| 12 | `AppTopbar.vue` + `MainLayout.vue` | `QuickDrawer` dirender dua kali | Dua drawer sekaligus |
| 13 | `useConfirm.ts` | Panggilan ke-2 membuat promise pertama menggantung | Await tak pernah selesai |
| 14 | `useFormValidation.ts` | `numeric` meloloskan string spasi; reset tidak membersihkan `touched` dengan benar | Validasi lolos salah |
| 15 | `BaseModal` / `ConfirmDialog` / Toast | Tanpa `role=dialog`, Esc, aria-live | Aksesibilitas |

## B. Kebersihan repo
Dihapus: `cakra-web.zip` (zip di dalam zip), `HelloWorld.vue`, `style.css`, aset template Vite, `tailwind.config.js`
(diabaikan Tailwind v4; dark mode sudah di `main.css`), `.UiShowcaseView copy.vue`, `.env.d.ts` (salah nama/lokasi → diganti `src/env.d.ts`
yang benar-benar mengetik `VITE_*`), blok script 130 baris yang dikomentari di `AppSidebar.vue`.
Ditambah: `.env.example`, `.editorconfig`, `.gitattributes` (seluruh source semula CRLF → LF), `README.md`.

## C. Temuan yang BELUM diubah (perlu keputusan Anda)
1. **Dark mode setengah jadi**: ±39 dari 45 komponen tidak punya varian `dark:` (Sidebar, Input, Table, Modal, Login, Toast, dll).
   Saran: token warna semantik di `@theme` (`--color-surface`, `--color-border`, `--color-text`) lalu pakai `bg-surface` dst., bukan menyebar `dark:` di tiap kelas.
2. ~~Token di localStorage~~ → **sudah diganti model session cookie** (lihat `AUTH.md`). Tersisa di sisi backend: cookie HttpOnly/Secure/SameSite, CSRF, rate-limit login.
3. **`BaseFileUploader`**: kunci default `default_advanced_uploader` dipakai bersama semua instance, file disimpan di IndexedDB tanpa dibersihkan saat logout (bocor antar-user pada perangkat bersama), file oversize hanya diberi tanda tapi tetap diterima, dan ada `setTimeout 1000ms` palsu. Perlu: key per-form, hapus saat logout, tolak oversize, upload nyata ke backend.
4. **Dua sistem konfirmasi** (`useConfirm` + `useSwal`) dan dua formatter mata uang (`formatter.ts`, `useCurrency.ts`; yang kedua membuang tanda minus/desimal untuk string). Pilih satu.
5. **Versi dependency tidak bisa saya verifikasi** (mis. `axios ^1.21.1`, `pinia ^4.1.0`, `lucide-vue-next ^1.0.0`, `typescript ~6.0.3`). Pastikan `npm install` bersih dan `package-lock.json` konsisten; `@vue/devtools-api` di `dependencies` kemungkinan tidak perlu.
6. **`.env.production`** masih berisi `https://api.domainanda.com`. Jangan commit URL/rahasia produksi; isi lewat variabel CI.
7. `BaseInput`: `required` hanya visual (tidak diteruskan ke `<input>`), tidak ada `id`/`for`/`aria-invalid`/`aria-describedby`. Berlaku juga untuk Select/Textarea/Checkbox (hanya saya grep, belum saya baca satu per satu).
8. 25-an komponen UI lain (Mobile*, Stepper, MultiSelect, Avatar, dll.) dan `UiShowcaseView` belum saya baca baris per baris.

## D. Yang kurang untuk fondasi "advanced enterprise"
- **Kualitas**: ESLint (flat config + `eslint-plugin-vue` + `typescript-eslint`), Prettier check, Vitest + Vue Test Utils (mulai dari `formatter`, `useFormValidation`, `auth.store.filterMenus`, router guard), Playwright untuk alur login/izin, husky + lint-staged, CI (typecheck, lint, test, build).
  Perintah (biar npm memilih versi yang cocok dengan Vite/TS Anda):
  `npm i -D eslint eslint-plugin-vue typescript-eslint @vue/eslint-config-typescript @vue/eslint-config-prettier prettier vitest @vue/test-utils jsdom husky lint-staged`
- **Arsitektur**: lapisan API per modul (`modules/<x>/api.ts` + tipe), TanStack Query (`@tanstack/vue-query`) untuk cache/retry/loading, interceptor refresh-token, `AbortController` pada navigasi, error boundary per route.
- **UX enterprise**: i18n (`vue-i18n`; teks sekarang hard-coded Indonesia), halaman 403/500, skeleton loader, Ctrl+K command palette (kotak pencarian topbar masih dekoratif), breadcrumbs dari `meta`, dirty-form guard, idle timeout/sesi kedaluwarsa, audit log aksi sensitif.
- **Keamanan**: Content-Security-Policy, rate-limit/lockout login di backend, sanitasi HTML Quill sebelum disimpan/ditampilkan (DOMPurify), `npm audit` di CI.
- **Operasional**: Dockerfile + nginx (SPA fallback, header keamanan, cache aset ber-hash), Sentry/observability, `vite-bundle-visualizer`, split chunk (Quill + SweetAlert2 berat → lazy import), PWA bila perlu POS offline.
- **Dokumentasi**: ADR singkat (kenapa menu dinamis dari backend), kontrak `/auth/me` (tipe `DynamicMenu`) bersama tim backend CI4.
