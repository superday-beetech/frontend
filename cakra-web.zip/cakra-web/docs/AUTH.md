# Autentikasi — kontrak frontend ↔ backend (CI4)

Web memakai **session cookie**. Token Bearer disiapkan untuk klien Flutter nanti dan TIDAK dipakai di web.

## Alur web
1. Buka aplikasi → `GET /auth/me` (dengan cookie). `200` = sudah login, `401` = belum login.
2. Login → `POST /auth/login {email, password}` → backend membuat session dan `Set-Cookie` (HttpOnly). Body tidak perlu mengembalikan token.
3. Frontend lalu memanggil `GET /auth/me` → user, permissions, menus → route & sidebar dibangun.
4. Logout → `POST /auth/logout` (session dihancurkan di server).
5. API mana pun membalas `401` → frontend membersihkan state dan kembali ke login (tanpa reload).

Kontrak `GET /auth/me` (sama untuk web dan Flutter):
```json
{ "status": true, "message": "OK",
  "data": { "user": {"id":1,"name":"...","email":"...","role":"..."},
            "permissions": ["master.product.view"],
            "menus": [ { "id":1, "parent_id":null, "title":"...", "path":"/", "name":"Dashboard",
                         "component_key":null, "icon":"LayoutDashboard", "permissions":[], "children":[] } ] } }
```
Permission `"*"` = semua akses.

## Yang HARUS diatur di backend CI4
- **Cookie session**: `HttpOnly`, `Secure` (produksi/HTTPS), `SameSite=Lax` (web & API satu situs, mis. `app.cakra.id` + `api.cakra.id`). `Config\Cookie`/`Config\Session`.
- **Regenerasi session ID saat login** (cegah session fixation).
- **CSRF**: aktifkan filter `csrf` (mode cookie). Frontend mengirim header `X-CSRF-TOKEN` dari cookie `csrf_cookie_name`;
  jika `$cookieName`/`$headerName` di `Config\Security` diubah, samakan di `src/core/api/client.ts`.
- **CORS** (bila beda subdomain): origin web spesifik (bukan `*`) + `Access-Control-Allow-Credentials: true`.
- **Rate-limit & lockout** pada `/auth/login`; session timeout (idle) yang jelas.
- **Otorisasi selalu di backend.** `v-can`, filter menu, dan guard router hanyalah kosmetik.

## Development
`npm run dev` memanggil `/api/...` lewat proxy Vite ke `VITE_DEV_API_TARGET` agar cookie same-origin (perilaku sama seperti produksi).
Dengan `VITE_USE_MOCK=true`, login ditiru memakai `sessionStorage` (hanya DEV).

## Nanti untuk Flutter
Endpoint yang sama bisa menerima `Authorization: Bearer <token>` (backend mendukung dua mode). Kontrak `/auth/me` identik, sehingga logika izin tidak terpecah.
