# Arsitektur — cakra-web

Prinsip: **sederhana, berlapis, searah**. Satu aturan inti: *lapisan atas boleh memakai lapisan bawah, tidak sebaliknya.*

```
            ┌──────────────────────────────────────────────┐
  app/      │ perakitan: router, layout, plugin, main.ts   │  boleh tahu semuanya
            └───────────────┬───────────────┬──────────────┘
                            ▼               ▼
  modules/<x>/   fitur bisnis (auth, dashboard, finance, …)   ← 1 modul = 1 domain
                            │
                            ▼
  shared/        komponen UI, composable, tipe lintas modul   ← tanpa logika bisnis
                            │
                            ▼
  core/          infrastruktur murni: HTTP, env, storage, util ← tanpa Vue UI & tanpa domain
```

| Lapisan   | Boleh mengimpor                                                          | Isi                                                        |
| --------- | ------------------------------------------------------------------------ | ---------------------------------------------------------- |
| `core`    | `core`                                                                   | klien HTTP, error helper, `env`, storage, formatter, util  |
| `shared`  | `core`, `shared`                                                         | `components/ui/*`, `composables/*`, `types/*`              |
| `modules` | `core`, `shared`, dirinya (import **relatif**), modul lain via `@/modules/<x>` | views, api, composables, stores, types, components  |
| `app`     | semua; modul hanya via `@/modules/<x>` (kecuali lazy view di `app/router`) | `main.ts`, router, layout, plugin                          |

Aturan ini **ditegakkan otomatis**: `npm run check:arch` (juga di CI). Ia juga melarang `import.meta.env` di luar `core/config/env.ts`
dan memastikan semua import terselesaikan.

## Peta folder

```
src/
  app/
    main.ts            titik masuk (hanya merakit)
    App.vue            RouterView + toast + dialog konfirmasi global
    plugins/           directives, error-handler, http (401 → login)
    router/            routes (statis) · dynamic-routes (dari menu backend) · guards · meta.d.ts
    layouts/           MainLayout + components/ (Sidebar, Topbar, …) + useLayout
    views/             halaman level-aplikasi (NotFound)
  core/
    api/               client (axios) · request (apiGet/apiPost/apiList) · errors · types
    config/env.ts      SATU-SATUNYA pembaca import.meta.env
    storage/           STORAGE_KEYS + safeStorage
    utils/             formatter, redirect, generator (fungsi murni, mudah dites)
  shared/
    components/ui/     primitives · form · feedback · overlay · data · mobile
    composables/       useToast, useConfirm, useTheme, useFormValidation, useMobileCalendar
    types/
  modules/<modul>/
    views/             halaman; nama file = bagian dari component_key backend
    components/        komponen khusus modul
    composables/       logika tampilan/use-case (state, loading, error)
    api/               <modul>.api.ts — satu-satunya tempat memanggil endpoint modul
    stores/            Pinia, HANYA untuk state lintas halaman
    mocks/             data simulasi (di-import dinamis; tidak masuk build produksi)
    types.ts           tipe domain modul
    index.ts           API publik modul (apa yang boleh dipakai pihak luar)
```

## Di mana saya menaruh…?

| Kebutuhan                                         | Tempat                                                      |
| ------------------------------------------------- | ----------------------------------------------------------- |
| Halaman baru                                      | `modules/<x>/views/NamaView.vue` + menu backend (`component_key: "<x>/NamaView"`) |
| Panggilan endpoint                                | `modules/<x>/api/<x>.api.ts` (pakai `apiGet/apiList/…` dari core) |
| Logika halaman (loading, filter, submit)          | `modules/<x>/composables/useNama.ts` — view tetap tipis     |
| State yang dipakai banyak halaman                 | `modules/<x>/stores/*.store.ts` (Pinia)                     |
| Komponen dipakai ≥ 2 modul                        | `shared/components/ui/<kelompok>/`                          |
| Komponen hanya dipakai satu modul                 | `modules/<x>/components/`                                   |
| Fungsi murni (format, hitung, validasi)           | `core/utils/` (atau `modules/<x>/utils/` bila spesifik domain) |
| Variabel lingkungan baru                          | `.env.example` + `env.d.ts` + `core/config/env.ts`          |
| Kunci localStorage                                | `core/storage` → `STORAGE_KEYS`                             |
| Hal yang dipakai modul lain                       | ekspor lewat `modules/<x>/index.ts`                         |

Modul baru: `npm run gen:module -- inventory` (membuat kerangka lengkap yang sudah lolos aturan arsitektur).

## Konvensi

- **Nama file**: komponen/view `PascalCase.vue`; composable `useXxx.ts`; store `xxx.store.ts`; API `xxx.api.ts`; test `xxx.spec.ts` di samping file yang dites.
- **Import**: lintas folder pakai alias `@/…`; di dalam satu modul pakai relatif. Tanpa barrel file kecuali `modules/<x>/index.ts`.
- **View tipis**: view merakit komponen + memanggil composable. Tidak ada `http.get` di view/komponen.
- **Server state vs client state**: data dari API hidup di composable (per halaman) — jangan dimasukkan ke Pinia kecuali dipakai lintas halaman.
- **Error**: pakai `getApiErrorMessage` / `getFieldErrors` / `isCancelledError` dari `core/api/errors`. Error 401 ditangani global (`app/plugins/http.ts`).
- **Konfirmasi & notifikasi**: `useConfirm()` dan `useToast()` — hanya itu.
- **Otorisasi**: `v-can`, filter menu, dan guard router hanya kosmetik; backend yang memutuskan.
- **Mock**: hanya DEV + `VITE_USE_MOCK=true`, di-import dinamis dari `api/*.api.ts`.

## Alur aplikasi

1. `main.ts` merakit Pinia, router, plugin → mount.
2. Guard router pertama kali memanggil `GET /auth/me` (`restoreSession`).
3. Belum login → `/login`. Sudah login → menu dari backend diubah jadi route anak `MainLayout` (`dynamic-routes.ts`), lalu navigasi diulang.
4. 401 dari API mana pun → `app/plugins/http.ts` membersihkan sesi, menghapus route dinamis, mengarahkan ke login.

## Testing & kualitas

| Perintah               | Fungsi                                                           |
| ---------------------- | ---------------------------------------------------------------- |
| `npm run check`        | arsitektur + typecheck (tanpa paket tambahan)                    |
| `npm run check:arch`   | aturan lapisan, `import.meta.env`, import tak terselesaikan      |
| `npm run lint`         | ESLint (perlu paket dev, lihat README)                           |
| `npm test`             | Vitest — logika murni dulu (formatter, izin, error, redirect)    |
| `npm run build`        | `vue-tsc -b` + `vite build`                                      |

Prioritas test: fungsi murni & composable → store → guard router → komponen kritis → E2E (Playwright) untuk login/izin.

## Jalur menuju "advanced" (bertahap — jangan sekaligus)

1. **Sekarang (fondasi)**: lapisan + aturan otomatis, modul auth lengkap, API layer, env terpusat, satu sistem konfirmasi, CI, Docker.
2. **Berikutnya**: `@tanstack/vue-query` untuk server state (cache/retry/invalidasi) menggantikan `loading/error` manual di composable;
   token warna semantik untuk dark mode penuh (`docs/AUDIT.md` C1); `vue-i18n`; halaman 403/500; dirty-form guard.
3. **Lanjutan**: Playwright E2E; Sentry di `app/plugins/error-handler.ts`; CSP di nginx; lazy-load Quill; idle-timeout sesi; PWA bila POS perlu offline;
   pisah modul besar menjadi paket (monorepo) bila tim > 1 squad.
