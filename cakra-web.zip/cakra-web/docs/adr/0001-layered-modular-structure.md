# ADR 0001 — Struktur berlapis & modular

- Status: diterima (17 Nov 2026)
- Konteks: sebelumnya `core/` memuat auth + router yang mengimpor `shared/`; `shared/layouts` mengimpor store auth; ada dua sistem
  konfirmasi dan dua formatter mata uang. Batas tanggung jawab kabur sehingga perubahan satu area merembet ke area lain.
- Keputusan: empat lapisan searah (`core` → `shared` → `modules` → `app`), modul berfitur vertikal dengan API publik `index.ts`,
  aturan ditegakkan skrip tanpa dependensi (`scripts/check-architecture.mjs`) dan dijalankan di CI.
- Alternatif ditolak: feature-sliced design penuh (terlalu banyak lapisan untuk ukuran sekarang); monorepo paket (belum perlu).
- Konsekuensi: modul baru murah (`npm run gen:module`); lintas-modul harus lewat `index.ts`; komponen yang dipakai ≥ 2 modul dipindah ke `shared`.
