# Cakra Enterprise — Web

Vue 3 + TypeScript + Vite + Tailwind v4 + Pinia. Struktur berlapis & modular — baca **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** sebelum menambah fitur.

## Menjalankan
```bash
cp .env.example .env.local   # API dipanggil lewat proxy Vite (VITE_DEV_API_TARGET)
npm install
npm run dev                  # mock API aktif bila VITE_USE_MOCK=true (khusus development)
npm run check                # aturan arsitektur + typecheck
npm run build                # vue-tsc + vite build
```

## Tooling kualitas (sekali pasang)
`lint`, `format`, dan `test` memakai paket yang belum ada di `package.json` (versi dipilih npm agar cocok dengan Vite/TS Anda):
```bash
npm i -D eslint @eslint/js typescript-eslint eslint-plugin-vue prettier vitest
git add package.json package-lock.json   # lalu commit; CI memakai `npm ci`
```
Setelah itu: `npm run lint`, `npm test`, `npm run format` (jalankan `format` sekali untuk menyeragamkan kode lama).

## Perintah
| Perintah | Fungsi |
|---|---|
| `npm run gen:module -- <nama>` | buat kerangka modul baru yang sesuai standar |
| `npm run check:arch` | tegakkan aturan lapisan (tanpa dependensi) |
| `npm test` / `npm run test:watch` | Vitest |

## Aturan penting
- Menu & route dinamis datang dari `/auth/me` (`component_key` = `modul/NamaView`).
- `v-can` / menu terfilter hanya mengatur **tampilan**; otorisasi wajib di backend.
- Autentikasi web = session cookie (HttpOnly) + CSRF; kontrak backend di [docs/AUTH.md](docs/AUTH.md).
- Mock tidak ikut ter-bundle di build produksi. Redirect pasca-login divalidasi (`isSafeRedirect`).
- Variabel lingkungan hanya dibaca lewat `core/config/env.ts`.

## Deploy
`docker build -t cakra-web .` → nginx menyajikan SPA (fallback `index.html`, cache aset ber-hash, header keamanan dasar).
CI: `.github/workflows/ci.yml`. Riwayat audit: [docs/AUDIT.md](docs/AUDIT.md). Keputusan arsitektur: [docs/adr](docs/adr).
